package com.virtusa.reporting_service.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WarehousePerformanceResponse {

    private String warehouseName;

    private Integer inboundCount;

    private Integer outboundCount;

    private Integer transferCount;
}