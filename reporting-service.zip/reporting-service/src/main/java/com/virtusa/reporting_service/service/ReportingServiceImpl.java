package com.virtusa.reporting_service.service;


import com.virtusa.reporting_service.client.InventoryClient;
import com.virtusa.reporting_service.client.ProductClient;
import com.virtusa.reporting_service.client.WarehouseClient;
import com.virtusa.reporting_service.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class ReportingServiceImpl
        implements ReportingService {

    private final ProductClient productClient;

    private final InventoryClient inventoryClient;

    private final WarehouseClient warehouseClient;

    @Override
    public List<InventoryValuationResponse>
    getInventoryValuation() {

        List<ProductDto> products =
                productClient.getProducts();

        List<InventoryDto> inventories =
                inventoryClient.getInventory();

        return inventories.stream()
                .map(inventory -> {

                    ProductDto product =
                            products.stream()
                                    .filter(p ->
                                            p.getId().equals(
                                                    inventory.getProductId()))
                                    .findFirst()
                                    .orElse(null);

                    if (product == null) {
                        return null;
                    }

                    double totalValue =
                            inventory.getQuantity()
                                    * product.getPrice();

                    return InventoryValuationResponse
                            .builder()
                            .productName(product.getName())
                            .quantity(inventory.getQuantity())
                            .unitPrice(product.getPrice())
                            .totalValue(totalValue)
                            .build();
                })
                .filter(Objects::nonNull)
                .toList();
    }

    @Override
    public StockMovementResponse
    getStockMovementReport() {

        /*
         * Placeholder.
         *
         * Later:
         * Call Inventory Service
         * transaction endpoint.
         */

        return StockMovementResponse
                .builder()
                .inbound(150)
                .outbound(80)
                .transfers(30)
                .adjustments(5)
                .build();
    }

    @Override
    public List<WarehousePerformanceResponse>
    getWarehousePerformance() {

        return warehouseClient
                .getWarehouses()
                .stream()
                .map(warehouse ->
                        WarehousePerformanceResponse
                                .builder()
                                .warehouseName(
                                        warehouse.getName())
                                .inboundCount(120)
                                .outboundCount(90)
                                .transferCount(15)
                                .build())
                .toList();
    }

    @Override
    public List<ForecastResponse>
    getForecast() {

        /*
         * Simple forecasting.
         *
         * Formula:
         *
         * Average Daily Demand
         * × 30 Days
         */

        return List.of(
                ForecastResponse.builder()
                        .productName("Laptop")
                        .averageDailyDemand(10.0)
                        .forecastFor30Days(300)
                        .build()
        );
    }
}